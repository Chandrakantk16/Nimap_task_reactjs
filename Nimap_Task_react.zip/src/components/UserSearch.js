import "../index.css";
import Navbar from "./Navbar";

function UserSearch() {
  return (
    <div>
      <Navbar />
    </div>
  );
}

export default UserSearch;